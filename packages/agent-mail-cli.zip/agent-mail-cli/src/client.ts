import * as signalR from '@microsoft/signalr';
import { MailPushNotification, SignalRConfig, ConnectionState } from './types';

export class AgentMailSignalRClient {
  private connection: signalR.HubConnection | null = null;
  private config: SignalRConfig;
  private currentState: ConnectionState = 'disconnected';
  private subscribedAgents: Set<string> = new Set();
  private reconnectAttempts = 0;
  private lastToken: string | null = null;
  private tokenRefreshTimer: NodeJS.Timeout | null = null;

  constructor(config: SignalRConfig) {
    this.config = config;
  }

  get state(): ConnectionState {
    return this.currentState;
  }

  get isConnected(): boolean {
    return this.connection?.state === signalR.HubConnectionState.Connected;
  }

  get subscribedAgentsList(): string[] {
    return Array.from(this.subscribedAgents);
  }

  async connect(): Promise<void> {
    if (this.connection?.state === signalR.HubConnectionState.Connected) {
      console.log('[SignalR] Already connected');
      return;
    }

    this.setState('connecting');

    try {
      const token = await this.config.getAccessToken();
      if (!token) {
        throw new Error('No access token available');
      }
      this.lastToken = token;

      this.connection = new signalR.HubConnectionBuilder()
        .withUrl(this.config.hubUrl, {
          accessTokenFactory: async () => {
            const freshToken = await this.config.getAccessToken();
            if (freshToken) this.lastToken = freshToken;
            return this.lastToken || '';
          },
          transport: signalR.HttpTransportType.WebSockets | 
                     signalR.HttpTransportType.ServerSentEvents |
                     signalR.HttpTransportType.LongPolling
        })
        .withAutomaticReconnect({
          nextRetryDelayInMilliseconds: (retryContext) => {
            const delays = [0, 2000, 5000, 10000, 30000];
            const delay = delays[Math.min(retryContext.previousRetryCount, delays.length - 1)];
            console.log(`[SignalR] Reconnecting in ${delay}ms (attempt ${retryContext.previousRetryCount + 1})`);
            return delay;
          }
        })
        .configureLogging(signalR.LogLevel.Warning)
        .build();

      this.setupEventHandlers();
      await this.connection.start();
      
      console.log('[SignalR] ✅ Connected to hub');
      this.setState('connected');
      this.reconnectAttempts = 0;
      this.startTokenRefreshTimer();

    } catch (error) {
      console.error('[SignalR] ❌ Connection failed:', error);
      this.setState('disconnected');
      throw error;
    }
  }

  async disconnect(): Promise<void> {
    this.stopTokenRefreshTimer();
    this.subscribedAgents.clear();
    
    if (this.connection) {
      try {
        await this.connection.stop();
        console.log('[SignalR] Disconnected');
      } catch (error) {
        console.error('[SignalR] Error during disconnect:', error);
      } finally {
        this.connection = null;
        this.setState('disconnected');
      }
    }
  }

  async subscribeToAgents(agentNames: string[]): Promise<void> {
    if (!this.connection || this.connection.state !== signalR.HubConnectionState.Connected) {
      throw new Error('Not connected to hub');
    }

    if (agentNames.length === 0) return;

    try {
      const result = await this.connection.invoke('SubscribeToAgents', agentNames);
      console.log('[SignalR] Subscribe result:', result);

      if (result.subscribed) {
        result.subscribed.forEach((agent: string) => this.subscribedAgents.add(agent));
      }

      if (result.denied?.length > 0) {
        console.warn('[SignalR] Access denied to agents:', result.denied);
      }

      return result;
    } catch (error) {
      console.error('[SignalR] Subscribe failed:', error);
      throw error;
    }
  }

  async unsubscribeFromAgents(agentNames: string[]): Promise<void> {
    if (!this.connection || this.connection.state !== signalR.HubConnectionState.Connected) {
      return;
    }

    try {
      await this.connection.invoke('UnsubscribeFromAgents', agentNames);
      agentNames.forEach(agent => this.subscribedAgents.delete(agent));
    } catch (error) {
      console.error('[SignalR] Unsubscribe failed:', error);
    }
  }

  private startTokenRefreshTimer(): void {
    this.stopTokenRefreshTimer();
    this.tokenRefreshTimer = setInterval(async () => {
      if (this.isConnected) {
        try {
          const freshToken = await this.config.getAccessToken();
          if (freshToken) this.lastToken = freshToken;
        } catch (error) {
          console.error('[SignalR] Token refresh failed:', error);
        }
      }
    }, 45 * 60 * 1000); // 45 minutes
  }

  private stopTokenRefreshTimer(): void {
    if (this.tokenRefreshTimer) {
      clearInterval(this.tokenRefreshTimer);
      this.tokenRefreshTimer = null;
    }
  }

  private setupEventHandlers(): void {
    if (!this.connection) return;

    this.connection.on('Connected', (data) => {
      console.log('[SignalR] Server confirmed connection:', data.connection_id);
    });

    this.connection.on('Subscribed', (data) => {
      console.log('[SignalR] Subscribed to:', data.subscribed);
    });

    this.connection.on('ReceiveNotification', (notification: MailPushNotification) => {
      this.config.onNotification?.(notification);
    });

    this.connection.on('Error', (error) => {
      console.error('[SignalR] Server error:', error);
      this.config.onError?.(new Error(error.message || 'Unknown server error'));
    });

    this.connection.onreconnecting((error) => {
      console.log('[SignalR] 🔄 Reconnecting...', error?.message);
      this.setState('reconnecting');
    });

    this.connection.onreconnected(async (connectionId) => {
      console.log('[SignalR] ✅ Reconnected:', connectionId);
      this.setState('connected');
      if (this.subscribedAgents.size > 0) {
        await this.subscribeToAgents(Array.from(this.subscribedAgents));
      }
    });

    this.connection.onclose(async (error) => {
      console.log('[SignalR] Connection closed:', error?.message);
      this.setState('disconnected');

      const isAuthError = error?.message?.includes('401') || 
                          error?.message?.includes('Unauthorized');

      if (isAuthError) {
        console.log('[SignalR] Auth error, attempting refresh and reconnect...');
        try {
          const freshToken = await this.config.getAccessToken();
          if (freshToken) {
            await new Promise(r => setTimeout(r, 1000));
            await this.connect();
            return;
          }
        } catch (e) {
          console.error('[SignalR] Reconnect failed:', e);
        }
      }

      this.subscribedAgents.clear();
    });
  }

  private setState(state: ConnectionState): void {
    if (this.currentState !== state) {
      this.currentState = state;
      this.config.onStateChange?.(state);
    }
  }
}