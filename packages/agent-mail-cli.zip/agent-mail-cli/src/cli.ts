#!/usr/bin/env node
import { Command } from 'commander';
import chalk from 'chalk';
import { AuthManager } from './auth';
import { AgentMailSignalRClient } from './client';
import { MailPushNotification } from './types';

const program = new Command();

program
  .name('vibe-agent')
  .description('CLI for Vibe Agent Mail and notifications')
  .version('1.0.0');

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Global options
program
  .option('-u, --url <url>', 'API base URL', 'https://api.idealvibe.online')
  .option('--idp-url <url>', 'IDP base URL (defaults to api url with port 32785)');

// ============ LOGIN COMMAND ============
program
  .command('login')
  .description('Authenticate via device code flow (requires HMAC credentials)')
  .option('-c, --client <slug>', 'Client slug', 'idealvibe')
  .requiredOption('--client-id <id>', 'HMAC Client ID (env: VIBE_CLIENT_ID)')
  .requiredOption('--hmac-key <key>', 'HMAC Key (env: VIBE_HMAC_KEY)')
  .action(async (options, cmd) => {
    const globalOpts = cmd.optsWithGlobals();
    const auth = new AuthManager({
      apiUrl: globalOpts.url,
      idpUrl: globalOpts.idpUrl,
      clientId: options.clientId,
      hmacKey: options.hmacKey,
    });

    console.log(chalk.blue('🔑 Starting device code flow...'));

    const flow = await auth.startDeviceCodeFlow(options.client);
    if (!flow) {
      console.error(chalk.red('❌ Failed to start device code flow'));
      process.exit(1);
    }

    console.log(chalk.green('\n✅ Device code flow started!'));
    console.log(chalk.white('\n📱 To complete authentication:'));
    console.log(chalk.white(`   1. Go to: ${chalk.cyan(flow.verification_url || 'https://idealvibe.online/auth/device')}`));
    console.log(chalk.white(`   2. Enter code: ${chalk.yellow.bold(flow.user_code)}`));
    console.log(chalk.gray(`\n⏳ Waiting for approval (expires in ${flow.expires_in}s)...\n`));

    const expiresAt = Date.now() + (flow.expires_in * 1000);
    const pollInterval = (flow.interval || 5) * 1000;

    while (Date.now() < expiresAt) {
      await sleep(pollInterval);

      const result = await auth.pollDeviceCode(flow.device_code);

      if (result.success && result.tokens) {
        console.log(chalk.green('\n✅ Authenticated successfully!'));
        if (result.tokens.userEmail) {
          console.log(chalk.gray(`   User: ${result.tokens.userEmail}`));
        }
        console.log(chalk.gray(`   Token expires in ${new Date(result.tokens.expiresAt).toLocaleString()}`));
        process.exit(0);
      }

      if (result.error === 'pending') {
        process.stdout.write(chalk.gray('.'));
        continue;
      }

      if (result.error === 'slow_down') {
        process.stdout.write(chalk.yellow('⚡'));
        continue;
      }

      console.error(chalk.red('\n❌ Authentication failed:'), result.error);
      process.exit(1);
    }

    console.error(chalk.red('\n❌ Device code expired'));
    process.exit(1);
  });

// ============ LOGOUT COMMAND ============
program
  .command('logout')
  .description('Clear stored credentials')
  .action(async (_options, cmd) => {
    const globalOpts = cmd.optsWithGlobals();
    const auth = new AuthManager({
      apiUrl: globalOpts.url,
      idpUrl: globalOpts.idpUrl,
    });

    await auth.logout();
    console.log(chalk.green('👋 Logged out'));
  });

// ============ STATUS COMMAND ============
program
  .command('status')
  .description('Show current authentication status')
  .action(async (_options, cmd) => {
    const globalOpts = cmd.optsWithGlobals();
    const auth = new AuthManager({
      apiUrl: globalOpts.url,
      idpUrl: globalOpts.idpUrl,
    });

    const status = await auth.getStatus();

    if (status.authenticated) {
      console.log(chalk.green('✅ Authenticated'));
      if (status.userEmail) {
        console.log(chalk.gray(`   User: ${status.userEmail}`));
      }
      if (status.userId) {
        console.log(chalk.gray(`   User ID: ${status.userId}`));
      }
      if (status.expiresAt) {
        const expiresIn = Math.floor((new Date(status.expiresAt).getTime() - Date.now()) / 1000);
        console.log(chalk.gray(`   Expires: ${status.expiresAt} (${expiresIn}s)`));
      }
    } else {
      console.log(chalk.red('❌ Not authenticated'));
      console.log(chalk.gray('   Run: vibe-agent login'));
    }
  });

// ============ LISTEN COMMAND ============
program
  .command('listen')
  .description('Listen for push notifications')
  .requiredOption('-a, --agents <agents...>', 'Agent names to subscribe to')
  .option('--hub <url>', 'SignalR hub URL', 'https://api.idealvibe.online/hubs/agentmail')
  .option('-f, --format <format>', 'Output format (json|pretty)', 'pretty')
  .action(async (options, cmd) => {
    const globalOpts = cmd.optsWithGlobals();
    const auth = new AuthManager({
      apiUrl: globalOpts.url,
      idpUrl: globalOpts.idpUrl,
    });

    if (!(await auth.isAuthenticated())) {
      console.error(chalk.red('❌ Not authenticated. Run: vibe-agent login'));
      process.exit(1);
    }

    const client = new AgentMailSignalRClient({
      hubUrl: options.hub,
      getAccessToken: () => auth.getAccessToken(),
      onNotification: (notification: MailPushNotification) => {
        if (options.format === 'json') {
          console.log(JSON.stringify(notification));
        } else {
          printNotification(notification);
        }
      },
      onStateChange: (state) => {
        if (options.format === 'pretty') {
          console.log(chalk.gray(`[State] ${state}`));
        }
      },
      onError: (error) => {
        console.error(chalk.red('❌ Error:'), error.message);
      },
    });

    const shutdown = async () => {
      console.log(chalk.yellow('\n👋 Shutting down...'));
      await client.disconnect();
      process.exit(0);
    };

    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);

    try {
      await client.connect();
      await client.subscribeToAgents(options.agents);

      console.log(chalk.green(`✅ Listening for notifications on: ${options.agents.join(', ')}`));
      console.log(chalk.gray('Press Ctrl+C to exit\n'));

      await new Promise(() => {});
    } catch (error) {
      console.error(chalk.red('❌ Failed to connect:'), error);
      process.exit(1);
    }
  });

// ============ SEND COMMAND ============
program
  .command('send')
  .description('Send a message via Agent Mail')
  .requiredOption('-f, --from <agent>', 'Sender agent name')
  .requiredOption('-t, --to <agents>', 'Recipient agent names (comma-separated)')
  .requiredOption('-s, --subject <subject>', 'Message subject')
  .option('-b, --body <body>', 'Message body', '')
  .option('-i, --importance <level>', 'Importance (low|normal|high|urgent)', 'normal')
  .option('--hmac', 'Use HMAC enterprise auth (no login required)')
  .option('--client-id <id>', 'HMAC Client ID (env: VIBE_CLIENT_ID)')
  .option('--hmac-key <key>', 'HMAC Key (env: VIBE_HMAC_KEY)')
  .option('--user-id <id>', 'User ID for service account mode (env: VIBE_USER_ID)')
  .action(async (options, cmd) => {
    const globalOpts = cmd.optsWithGlobals();
    const recipients = options.to.split(',').map((s: string) => s.trim());

    // HMAC mode
    if (options.hmac) {
      const clientId = options.clientId || process.env.VIBE_CLIENT_ID;
      const hmacKey = options.hmacKey || process.env.VIBE_HMAC_KEY;
      const userId = options.userId || process.env.VIBE_USER_ID;

      if (!clientId || !hmacKey) {
        console.error(chalk.red('❌ HMAC auth requires --client-id and --hmac-key'));
        process.exit(1);
      }

      const auth = new AuthManager({
        apiUrl: globalOpts.url,
        idpUrl: globalOpts.idpUrl,
        clientId,
        hmacKey,
        userId,
      });

      const response = await auth.sendMailWithHMAC({
        from_agent: options.from,
        to: recipients,
        subject: options.subject,
        body: options.body,
        importance: options.importance,
      });

      if (response.success) {
        console.log(chalk.green('✅ Message sent:'), response.data?.message_id || 'OK');
      } else {
        console.error(chalk.red('❌ Send failed:'), response.error?.message);
        process.exit(1);
      }
      return;
    }

    // JWT mode
    const auth = new AuthManager({
      apiUrl: globalOpts.url,
      idpUrl: globalOpts.idpUrl,
    });

    if (!(await auth.isAuthenticated())) {
      console.error(chalk.red('❌ Not authenticated. Run: vibe-agent login or use --hmac'));
      process.exit(1);
    }

    const token = await auth.getAccessToken();
    if (!token) {
      console.error(chalk.red('❌ Failed to get access token'));
      process.exit(1);
    }

    try {
      const response = await fetch(`${globalOpts.url}/v1/agentmail/send`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          from_agent: options.from,
          to: recipients,
          subject: options.subject,
          body: options.body,
          importance: options.importance,
        }),
      });

      const data = await response.json() as { success: boolean; data?: { message_id?: number }; error?: { message?: string } };

      if (data.success) {
        console.log(chalk.green('✅ Message sent:'), data.data?.message_id || 'OK');
      } else {
        console.error(chalk.red('❌ Send failed:'), data.error?.message);
        process.exit(1);
      }
    } catch (error) {
      console.error(chalk.red('❌ Send error:'), error);
      process.exit(1);
    }
  });

// ============ PIPE COMMAND ============
program
  .command('pipe')
  .description('Listen and pipe notifications to a command')
  .requiredOption('-a, --agents <agents...>', 'Agent names to subscribe to')
  .requiredOption('-c, --command <cmd>', 'Command to pipe to')
  .option('--hub <url>', 'SignalR hub URL', 'https://api.idealvibe.online/hubs/agentmail')
  .action(async (options, cmd) => {
    const globalOpts = cmd.optsWithGlobals();
    const auth = new AuthManager({
      apiUrl: globalOpts.url,
      idpUrl: globalOpts.idpUrl,
    });

    if (!(await auth.isAuthenticated())) {
      console.error(chalk.red('❌ Not authenticated'));
      process.exit(1);
    }

    const { spawn } = await import('child_process');

    const client = new AgentMailSignalRClient({
      hubUrl: options.hub,
      getAccessToken: () => auth.getAccessToken(),
      onNotification: (notification: MailPushNotification) => {
        const child = spawn('sh', ['-c', options.command], {
          stdio: ['pipe', 'inherit', 'inherit']
        });
        child.stdin.write(JSON.stringify(notification));
        child.stdin.end();
      },
      onError: (error) => {
        console.error(chalk.red('❌ Error:'), error.message);
      },
    });

    const shutdown = async () => {
      await client.disconnect();
      process.exit(0);
    };

    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);

    try {
      await client.connect();
      await client.subscribeToAgents(options.agents);
      console.log(chalk.green(`✅ Piping notifications to: ${options.command}`));
      await new Promise(() => {});
    } catch (error) {
      console.error(chalk.red('❌ Failed:'), error);
      process.exit(1);
    }
  });

function printNotification(notification: MailPushNotification): void {
  const { event_type, data } = notification;

  const icons: Record<string, string> = {
    new_message: '📬',
    agent_response: '↩️',
    mention: '👋',
    high_importance: '⚠️',
  };

  const colors: Record<string, (s: string) => string> = {
    new_message: chalk.blue,
    agent_response: chalk.cyan,
    mention: chalk.yellow,
    high_importance: chalk.red.bold,
  };

  const icon = icons[event_type] || '📨';
  const color = colors[event_type] || chalk.white;

  console.log('');
  console.log(color(`${icon} ${event_type.toUpperCase()}`));
  console.log(chalk.gray(`   From: ${data.from_agent}`));
  console.log(chalk.gray(`   To: ${data.to_agent}`));
  if (data.subject) console.log(chalk.white(`   Subject: ${data.subject}`));
  if (data.preview) console.log(chalk.gray(`   Preview: ${data.preview}`));
  console.log(chalk.gray(`   Time: ${new Date(data.created_at).toLocaleString()}`));
  console.log('');
}

program.parse();
