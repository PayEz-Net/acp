import * as os from 'os';
import * as path from 'path';
import { createHmac } from 'crypto';

// Keytar is optional - fallback to file storage if not available
let keytar: any;
try {
  keytar = require('keytar');
} catch {
  // keytar not available, will use file fallback
}

const SERVICE_NAME = 'vibe-agent-cli';
const ACCOUNT_NAME = 'agent-auth';

interface TokenData {
  accessToken: string;
  refreshToken?: string;
  expiresAt: string;
  clientId: string;
  userId?: number;
  userEmail?: string;
}

interface DeviceCodeStartResponse {
  device_code: string;
  user_code: string;
  verification_url: string;
  expires_in: number;
  interval: number;
}

interface DeviceCodePollResponse {
  status?: string;
  access_token?: string;
  refresh_token?: string;
  expires_in?: number;
  user_id?: number;
  user_email?: string;
}

interface HMACAuthHeaders {
  'X-Vibe-Client-Id': string;
  'X-Vibe-Timestamp': string;
  'X-Vibe-Signature': string;
  'X-Vibe-User-Id'?: string;
}

export class AuthManager {
  private apiUrl: string;
  private idpUrl: string;
  private clientId?: string;
  private hmacKey?: string;
  private userId?: string;
  private cachedTokens?: TokenData;

  constructor(options: {
    apiUrl: string;
    idpUrl?: string;
    clientId?: string;
    hmacKey?: string;
    userId?: string;
  }) {
    this.apiUrl = options.apiUrl;
    // Default IDP URL: if apiUrl contains port 32786, change to 32785
    // Otherwise assume IDP is at same URL as API
    if (options.idpUrl) {
      this.idpUrl = options.idpUrl;
    } else if (options.apiUrl.includes(':32786')) {
      this.idpUrl = options.apiUrl.replace(':32786', ':32785');
    } else {
      this.idpUrl = options.apiUrl;
    }
    this.clientId = options.clientId;
    this.hmacKey = options.hmacKey;
    this.userId = options.userId;
  }

  /**
   * Start device code flow for agent authentication
   * Returns device_code (for polling) and user_code (for user to enter)
   * Requires HMAC authentication
   */
  async startDeviceCodeFlow(clientSlug: string): Promise<DeviceCodeStartResponse | null> {
    if (!this.clientId || !this.hmacKey) {
      console.error('❌ HMAC credentials required for device code flow');
      return null;
    }

    try {
      const path = '/api/ExternalAuth/agent-device/start';
      const headers = this.generateHMACHeaders('POST', path);

      const response = await fetch(`${this.idpUrl}${path}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...headers,
        },
        body: JSON.stringify({
          client: clientSlug,
          device_id: 'vibe_agents_cli'
        }),
      });

      const text = await response.text();
      if (!response.ok || !text) {
        if (response.status === 404) {
          console.error('❌ Device code endpoint not found. Check --idp-url (default: same as --url)');
        } else {
          console.error('❌ Failed to start device code flow:', text || `HTTP ${response.status}`);
        }
        return null;
      }

      const result = JSON.parse(text) as { data?: DeviceCodeStartResponse } & DeviceCodeStartResponse;
      return result.data || result;
    } catch (error) {
      console.error('❌ Device code start error:', error);
      return null;
    }
  }

  /**
   * Poll for device code authorization status
   * Returns tokens when user approves
   */
  async pollDeviceCode(deviceCode: string): Promise<{
    success: boolean;
    tokens?: TokenData;
    error?: string;
  }> {
    try {
      const response = await fetch(`${this.idpUrl}/api/ExternalAuth/agent-device/poll`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ device_code: deviceCode }),
      });

      const text = await response.text();
      if (!text) {
        return { success: false, error: 'Empty response' };
      }

      const result = JSON.parse(text) as {
        data?: DeviceCodePollResponse;
        error?: { code?: string; message?: string };
      };

      if (!response.ok) {
        const errorCode = result.error?.code;
        if (errorCode === 'authorization_pending') {
          return { success: false, error: 'pending' };
        }
        if (errorCode === 'SLOW_DOWN') {
          return { success: false, error: 'slow_down' };
        }
        return { success: false, error: result.error?.message || 'Unknown error' };
      }

      const data: DeviceCodePollResponse = result.data || (result as unknown as DeviceCodePollResponse);

      if (data.access_token) {
        const tokens: TokenData = {
          accessToken: data.access_token,
          refreshToken: data.refresh_token,
          expiresAt: new Date(Date.now() + (data.expires_in || 3600) * 1000).toISOString(),
          clientId: this.clientId || '',
          userId: data.user_id,
          userEmail: data.user_email,
        };

        await this.saveTokens(tokens);
        return { success: true, tokens };
      }

      return { success: false, error: 'unknown_status' };
    } catch (error) {
      return { success: false, error: String(error) };
    }
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshToken(): Promise<boolean> {
    const tokens = await this.loadTokens();
    if (!tokens?.refreshToken) {
      return false;
    }

    try {
      const response = await fetch(`${this.idpUrl}/api/ExternalAuth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: tokens.refreshToken }),
      });

      const result = await response.json() as { data?: { access_token?: string; refresh_token?: string; expires_in?: number } };
      const data = result.data || result as unknown as { access_token?: string; refresh_token?: string; expires_in?: number };

      if (!data?.access_token) {
        return false;
      }

      const newTokens: TokenData = {
        accessToken: data.access_token,
        refreshToken: data.refresh_token || tokens.refreshToken,
        expiresAt: new Date(Date.now() + (data.expires_in || 3600) * 1000).toISOString(),
        clientId: tokens.clientId,
        userId: tokens.userId,
        userEmail: tokens.userEmail,
      };

      await this.saveTokens(newTokens);
      return true;
    } catch (error) {
      console.error('❌ Token refresh error:', error);
      return false;
    }
  }

  /**
   * Get valid access token (refreshing if needed)
   */
  async getAccessToken(): Promise<string | null> {
    let tokens = await this.loadTokens();
    if (!tokens) {
      return null;
    }

    // Check if token expires in < 5 minutes
    const expiresAt = new Date(tokens.expiresAt);
    const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000);

    if (expiresAt < fiveMinutesFromNow) {
      const refreshed = await this.refreshToken();
      if (!refreshed) {
        return null;
      }
      tokens = await this.loadTokens();
    }

    return tokens?.accessToken || null;
  }

  /**
   * Check if authenticated
   */
  async isAuthenticated(): Promise<boolean> {
    const tokens = await this.loadTokens();
    return !!tokens?.accessToken;
  }

  /**
   * Get current auth status
   */
  async getStatus(): Promise<{
    authenticated: boolean;
    userEmail?: string;
    userId?: number;
    expiresAt?: string;
    clientId?: string;
  }> {
    const tokens = await this.loadTokens();
    if (!tokens) {
      return { authenticated: false };
    }

    const expiresAt = new Date(tokens.expiresAt);
    const isValid = expiresAt > new Date();

    return {
      authenticated: isValid,
      userEmail: tokens.userEmail,
      userId: tokens.userId,
      expiresAt: tokens.expiresAt,
      clientId: tokens.clientId,
    };
  }

  /**
   * Logout - clear stored tokens
   */
  async logout(): Promise<void> {
    if (keytar) {
      await keytar.deletePassword(SERVICE_NAME, ACCOUNT_NAME);
    }
    this.cachedTokens = undefined;

    // Also clear file fallback
    try {
      const fs = await import('fs');
      const tokenFile = path.join(os.homedir(), '.vibe-agent', 'tokens.json');
      if (fs.existsSync(tokenFile)) {
        fs.unlinkSync(tokenFile);
      }
    } catch {
      // ignore errors
    }
  }

  /**
   * Save tokens to secure storage
   */
  private async saveTokens(tokens: TokenData): Promise<void> {
    this.cachedTokens = tokens;

    // Try keytar first (secure keychain)
    if (keytar) {
      try {
        await keytar.setPassword(SERVICE_NAME, ACCOUNT_NAME, JSON.stringify(tokens));
        return;
      } catch {
        // Fall through to file storage
      }
    }

    // Fallback to file storage
    const fs = await import('fs');
    const dir = path.join(os.homedir(), '.vibe-agent');
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    }
    fs.writeFileSync(
      path.join(dir, 'tokens.json'),
      JSON.stringify(tokens, null, 2),
      { mode: 0o600 }
    );
  }

  /**
   * Load tokens from secure storage
   */
  private async loadTokens(): Promise<TokenData | undefined> {
    if (this.cachedTokens) {
      return this.cachedTokens;
    }

    // Try keytar first
    if (keytar) {
      try {
        const encrypted = await keytar.getPassword(SERVICE_NAME, ACCOUNT_NAME);
        if (encrypted) {
          this.cachedTokens = JSON.parse(encrypted);
          return this.cachedTokens;
        }
      } catch {
        // Fall through to file storage
      }
    }

    // Fallback to file storage
    try {
      const fs = await import('fs');
      const tokenFile = path.join(os.homedir(), '.vibe-agent', 'tokens.json');
      if (fs.existsSync(tokenFile)) {
        const data = fs.readFileSync(tokenFile, 'utf-8');
        this.cachedTokens = JSON.parse(data);
        return this.cachedTokens;
      }
    } catch {
      // ignore errors
    }

    return undefined;
  }

  // ============ HMAC Enterprise Auth ============

  /**
   * Send mail using HMAC enterprise authentication (no JWT required)
   */
  async sendMailWithHMAC(mailData: {
    from_agent: string;
    to: string[];
    subject: string;
    body: string;
    importance: string;
  }): Promise<{
    success: boolean;
    data?: { message_id?: number };
    error?: { code?: string; message?: string };
  }> {
    if (!this.clientId || !this.hmacKey) {
      return {
        success: false,
        error: { code: 'NO_HMAC_CREDS', message: 'HMAC credentials not configured' }
      };
    }

    const path = '/v1/agentmail/send';
    const headers = this.generateHMACHeaders('POST', path);

    try {
      const response = await fetch(`${this.apiUrl}${path}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...headers,
        },
        body: JSON.stringify(mailData),
      });

      const data = await response.json() as { success: boolean; data?: { message_id?: number }; error?: { code?: string; message?: string } };
      return data;
    } catch (error) {
      return { success: false, error: { message: String(error) } };
    }
  }

  private generateHMACHeaders(method: string, path: string): HMACAuthHeaders {
    if (!this.clientId || !this.hmacKey) {
      throw new Error('HMAC credentials not configured');
    }

    const timestamp = Math.floor(Date.now() / 1000).toString();
    const message = `${timestamp}|${method.toUpperCase()}|${path}`;

    const signature = createHmac('sha256', Buffer.from(this.hmacKey, 'base64'))
      .update(message)
      .digest('base64');

    const headers: HMACAuthHeaders = {
      'X-Vibe-Client-Id': this.clientId,
      'X-Vibe-Timestamp': timestamp,
      'X-Vibe-Signature': signature,
    };

    if (this.userId) {
      headers['X-Vibe-User-Id'] = this.userId;
    }

    return headers;
  }
}

export { TokenData, DeviceCodeStartResponse };
