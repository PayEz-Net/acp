export { AgentMailSignalRClient } from './client';
export { AuthManager } from './auth';
export * from './types';

// Default export for convenience
export { AgentMailSignalRClient as default } from './client';