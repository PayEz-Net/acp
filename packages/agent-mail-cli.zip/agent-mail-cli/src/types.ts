/** Push notification event types */
export type MailPushEventType = 'new_message' | 'agent_response' | 'mention' | 'high_importance';

/** Push notification payload */
export interface MailPushNotification {
  event_type: MailPushEventType;
  timestamp: string;
  notification_id: string;
  data: {
    message_id: number;
    thread_id?: string;
    inbox_id: number;
    from_agent: string;
    from_agent_display: string;
    to_agent: string;
    subject?: string;
    preview?: string;
    importance: 'low' | 'normal' | 'high' | 'urgent';
    created_at: string;
  };
  metadata: {
    client_id: number;
    user_id?: number;
  };
}

/** Connection states */
export type ConnectionState = 'connecting' | 'connected' | 'reconnecting' | 'disconnected';

/** SignalR client configuration */
export interface SignalRConfig {
  hubUrl: string;
  getAccessToken: () => Promise<string | null>;
  onNotification?: (notification: MailPushNotification) => void;
  onStateChange?: (state: ConnectionState) => void;
  onError?: (error: Error) => void;
}

/** CLI options */
export interface CLIOptions {
  /** SignalR hub URL */
  hubUrl: string;
  /** Vibe API base URL (for auth) */
  apiUrl: string;
  /** Agent names to subscribe to */
  agents: string[];
  /** Email for login */
  email?: string;
  /** Password for login (prompted if not provided) */
  password?: string;
  /** Output format: json | pretty */
  format: 'json' | 'pretty';
  /** Run once and exit after receiving N notifications */
  count?: number;
  /** Watch mode - keep running */
  watch: boolean;
}