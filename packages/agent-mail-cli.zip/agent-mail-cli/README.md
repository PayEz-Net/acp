# @payez/agent-mail-cli

CLI tool and Node.js library for Agent Mail push notifications via SignalR.

## Installation

```bash
npm install -g @payez/agent-mail-cli
```

Or use locally:
```bash
npm install @payez/agent-mail-cli
```

## CLI Usage

### Login
```bash
agent-mail login -e your@email.com
# Enter password when prompted
```

Tokens are stored securely in `~/.agent-mail/tokens.json` with 0600 permissions.

### Watch for Notifications
```bash
# Watch all agents
agent-mail watch -a BAPert -a DotNetPert -a NextPert

# JSON output for piping
agent-mail watch -a BAPert --format json | jq '.data.subject'

# Exit after 5 notifications
agent-mail watch -a BAPert --count 5
```

### Send Test Message
```bash
agent-mail send \
  --from BAPert \
  --to DotNetPert \
  --subject "Test from CLI" \
  --body "This is a test message"
```

### Logout
```bash
agent-mail logout
```

## Library Usage

```typescript
import { AgentMailSignalRClient, AuthManager } from '@payez/agent-mail-cli';

// Auth
const auth = new AuthManager('https://api.idealvibe.online');
await auth.login('email', 'password');

// SignalR Client
const client = new AgentMailSignalRClient({
  hubUrl: 'https://api.idealvibe.online/hubs/agentmail',
  getAccessToken: () => auth.getAccessToken(),
  onNotification: (notification) => {
    console.log('New message:', notification.data.subject);
  },
  onStateChange: (state) => {
    console.log('Connection state:', state);
  },
});

await client.connect();
await client.subscribeToAgents(['BAPert', 'DotNetPert']);
```

## Features

- 🔐 Secure token storage with automatic refresh
- 🔄 Auto-reconnect with exponential backoff
- 📡 Real-time push notifications via SignalR
- 🎯 Subscribe to specific agents
- 📤 Send messages from CLI
- 🎨 Pretty or JSON output formats

## Environment Variables

```bash
# Override default API URL
export AGENT_MAIL_API_URL=https://api.idealvibe.online
export AGENT_MAIL_HUB_URL=https://api.idealvibe.online/hubs/agentmail
```

## Architecture

This CLI tool connects directly to the SignalR hub at `api.idealvibe.online`, 
receiving the same push notifications as the Electron ACP app.

```
┌─────────────┐      SignalR       ┌─────────────────┐
│  agent-mail │ ◄─────────────────►│  Vibe API       │
│    CLI      │    WebSocket/SSE   │  /hubs/agentmail│
└─────────────┘                    └─────────────────┘
       │                                   │
       │                              ┌────┴────┐
       │                              │  Redis  │
       └─────────────────────────────►│Backplane│
          REST API calls              └────┬────┘
                                          │
                                     ┌────┴────┐
                                     │  Agents  │
                                     │  notify  │
                                     └─────────┘
```